Name:

Joel Savitz

Functionality status:

Complete but inefficient.

Notes:

This assignment was easier than expected.