#include <iostream>
#include "StrBlob.h"
#include "StrBlobPtr.h"

using namespace std;

int main(void)
{
    StrBlob b1 = {"she", "he", "it"};
    StrBlob b2 = {"a", "an", "the"};

    cout << "b1: " << b1 << endl;
    cout << "b2: " << b2 << endl;

    b1 = b2;
    b2.push_back("about");

    cout << "b1: " << b1 << endl;
    cout << "b2: " << b2 << endl;

	StrBlobPtr sb1 = b1.begin();

	cout << "b1.begin() == " << sb1.deref() << endl;

	StrBlobPtr sb2(b1);

	while (true)
	{
		string s = sb2.deref();
		cout << "s: " << s << endl;
		sb1 = sb2.incr();
	}

    return 0;
}
